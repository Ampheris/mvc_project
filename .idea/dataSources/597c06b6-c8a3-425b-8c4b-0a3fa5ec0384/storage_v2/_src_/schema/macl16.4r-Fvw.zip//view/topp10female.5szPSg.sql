create definer = macl16@`%` view topp10female as
select `C`.`id`                              AS `id`,
       `C`.`manufacturer`                    AS `manufacturer`,
       `C`.`catId`                           AS `catId`,
       `C`.`brand`                           AS `brand`,
       `C`.`madeIn`                          AS `madeIn`,
       `C`.`weight`                          AS `weight`,
       `C`.`size`                            AS `size`,
       `C`.`price`                           AS `price`,
       `C`.`priceExklMoms`                   AS `priceExklMoms`,
       `C`.`color`                           AS `color`,
       `C`.`nrInStore`                       AS `nrInStore`,
       `C2`.`gender`                         AS `gender`,
       sum(`macl16`.`ShoppingCart`.`NrPurs`) AS `totaol_purs`
from ((`macl16`.`ShoppingCart` join `macl16`.`Clothes` `C` on ((`macl16`.`ShoppingCart`.`ArtNr` = `C`.`id`)))
         join `macl16`.`Category` `C2` on ((`C`.`catId` = `C2`.`catId`)))
where (`C2`.`gender` = 'Female')
group by `macl16`.`ShoppingCart`.`ArtNr`
order by sum(`macl16`.`ShoppingCart`.`NrPurs`) desc
limit 10;

