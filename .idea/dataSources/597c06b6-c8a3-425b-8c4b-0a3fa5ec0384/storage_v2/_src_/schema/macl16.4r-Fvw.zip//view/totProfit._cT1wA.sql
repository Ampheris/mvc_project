create definer = macl16@`%` view totProfit as
select sum(((`c`.`price` - `c`.`costPrice`) * (select sum(`macl16`.`ShoppingCart`.`NrPurs`)
                                               from `macl16`.`ShoppingCart`
                                               where (`macl16`.`ShoppingCart`.`ArtNr` = `c`.`id`)))) AS `Total`
from `macl16`.`Clothes` `c`;

