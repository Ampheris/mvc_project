create
    definer = macl16@`%` procedure filterIt(IN Genders varchar(20), IN Types varchar(20), IN SubTypes varchar(20))
BEGIN
    SELECT * FROM Clothes JOIN Category ON Clothes.catId = Category.catId WHERE Category.gender=Genders AND Category.type = Types AND Category.subtype = SubTypes;
  end;

