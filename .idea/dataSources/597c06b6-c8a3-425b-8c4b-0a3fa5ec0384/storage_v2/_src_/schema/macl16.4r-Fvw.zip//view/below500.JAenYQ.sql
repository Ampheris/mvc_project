create definer = macl16@`%` view below500 as
select `macl16`.`Clothes`.`id`            AS `id`,
       `macl16`.`Clothes`.`manufacturer`  AS `manufacturer`,
       `macl16`.`Clothes`.`catId`         AS `catId`,
       `macl16`.`Clothes`.`brand`         AS `brand`,
       `macl16`.`Clothes`.`madeIn`        AS `madeIn`,
       `macl16`.`Clothes`.`weight`        AS `weight`,
       `macl16`.`Clothes`.`size`          AS `size`,
       `macl16`.`Clothes`.`price`         AS `price`,
       `macl16`.`Clothes`.`priceExklMoms` AS `priceExklMoms`,
       `macl16`.`Clothes`.`color`         AS `color`,
       `macl16`.`Clothes`.`nrInStore`     AS `nrInStore`
from `macl16`.`Clothes`
where (`macl16`.`Clothes`.`price` < 500);

