create definer = macl16@`%` view clothesSoldSortedBestSold as
select distinct `c`.`id`            AS `id`,
                `c`.`manufacturer`  AS `manufacturer`,
                `c`.`catId`         AS `catId`,
                `c`.`brand`         AS `brand`,
                `c`.`madeIn`        AS `madeIn`,
                `c`.`weight`        AS `weight`,
                `c`.`size`          AS `size`,
                `c`.`price`         AS `price`,
                `c`.`priceExklMoms` AS `priceExklMoms`,
                `c`.`color`         AS `color`,
                `c`.`nrInStore`     AS `nrInStore`,
                `c`.`costPrice`     AS `costPrice`
from (`macl16`.`Clothes` `c`
         join `macl16`.`ShoppingCart` `s` on ((`c`.`id` = `s`.`ArtNr`)))
group by `s`.`ArtNr`
order by sum(`s`.`NrPurs`) desc;

