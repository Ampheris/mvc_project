create
    definer = macl16@`%` procedure sp_MellanDagsRea(IN lowerPriceVar float)
begin
    update Clothes
    set Clothes.price = Clothes.price * lowerPriceVar;
    update Clothes
    set Clothes.PriceExklMoms = Clothes.PriceExklMoms * lowerPriceVar;
  end;

